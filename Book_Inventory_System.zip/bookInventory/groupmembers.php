<?php
  require "includes/controller.php";
  require "includes/header.php";
  require "includes/logoutModal.php";
  if(empty($_SESSION['username']))
  {
    header("location:login.php");
  }
?>
<style>
.card {
  box-shadow: 0 8px 8px 0 rgba(0, 0, 0, 0.2);
}
</style>
<!DOCTYPE html>
<html lang="en">
  <body style="background-color: #f1aa9b;">
    <div id="wrapper">
      <!-- Sidebar -->
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">Book Inventory System&nbsp&nbsp<i class="fa fa-book"></i></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav side-nav">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="add.php"><i class="fa fa-plus-square"></i> Add Book</a></li>
            <li><a href="search.php"><i class="fa fa-search"></i> Search Book</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-list-ul"></i> Book Categories<b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="fiction.php" style="text-decoration: none; color: #FFFFFF;">Fiction</a></li>
                <li><a href="fantasy.php" style="text-decoration: none; color: #FFFFFF;">Fantasy</a></li>
                <li><a href="facts.php" style="text-decoration: none; color: #FFFFFF;">Facts</a></li>
                <li><a href="education.php" style="text-decoration: none; color: #FFFFFF;">Education</a></li>
              </ul>
            </li>
            <li><a href="userSetting.php"><i class="fa fa-users"></i> User Setting</a></li>
            <li><a href="groupmembers.php"><i class="fa fa-file"></i> Members Profile</a></li>
          </ul>  
        <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown user-dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i>&nbsp<?php echo $_SESSION['fullname'] ?> <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="#user<?php echo $_SESSION['username']?>" data-toggle="modal"><i class="fa fa-cog">&nbsp</i> Manage Account</a></li>
                <li class="divider"></li>
                <li><a href="#logout" data-toggle="modal"><i class="fa fa-power-off"></i> Log Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </nav>
      <?php include 'includes/userModal.php'; ?>
      <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h1>Group Profile</h1>
            <ol class="breadcrumb">
              <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li class="active"><i class="fa fa-file"></i> Group Profile</li>
            </ol>
          </div>
        </div><!-- /.row -->

    
      <div id="page-wrapper">
        <div class="row" >
          <div>
            <div class="table-responsive">
              <table>
                <tbody>
                  <tr>
                  <?php
                  $sql = "SELECT * FROM membersprofile";
                  $result = $conn->query($sql);
                  while($row=$result->fetch_assoc()):
                  ?>
                    <td>
                    <div class="card">
                      <center>
                      <img src="uploads/profilepicture/<?php echo $row['picture']; ?>" height="320" width="350"></center>
                      <div style="padding: 20px">
                      <h3 style="color: #ff4646;"><?php echo $row['name']; ?><small style="color: #ff4646;"> (<?php echo $row['ic'];?>)</small></h3>
                      <p style="color: #ffe05d;">Student ID: <?php echo $row['studentid'];?></p>
                      <p style="color: #4e8d7c;">Group: <?php echo $row['groupclass'];?></p>
                      <p style="color: #726a95;"><?php echo $row['programname'];?> (<?php echo $row['programcode'];?>) </p>
                      <p style="color: brown;"><i><?php echo $row['email'];?></i></p>
                      </div>
                    </div>
                    </td>
                    <?php endwhile; ?>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->
    
    </div><!-- /#wrapper -->
  </body>
</html>