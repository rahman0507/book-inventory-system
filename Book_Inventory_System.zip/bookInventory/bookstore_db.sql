-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 21, 2021 at 04:24 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstore_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `book_id` int(11) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `picture` varchar(50) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `descr` varchar(500) DEFAULT NULL,
  `pages` int(11) DEFAULT NULL,
  `price` decimal(7,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`book_id`, `title`, `author`, `picture`, `category`, `descr`, `pages`, `price`) VALUES
(1, 'Heaven Sent', 'Norhafsah Hamid', 'product_image.jpg', 'Fiction', 'Sarah Is A Muslim Girl Faced With Challenges And Obstacles To Remain True To Her Religion. Whilst She Endures Hardship, She Also Found Friendship And Love.', 173, '33.00'),
(2, 'Guinness World Records 2021', 'Guiness World Records', 'product_image (1).jpg', 'Fiction', '\'Jonah Is The \'Modern Day\' Rome And Enjoys The Company Of Women But When He Met Sarah, His Whole World Changed.', 329, '99.90'),
(3, 'The Lost Book Of The White', 'Cassandra Clare', 'product_image (2).jpg', 'Fiction', 'All Aboard Guinness World Records 2021 For A Life-Changing Journey Of Discovery! This Year, We\'re Devoting A Chapter To The History Of Exploration, Starting With The Story Of The Very First Circumnavigation, Along With Our \"History Of Adventure\" Timeline, Featuring A Host Of Remarkable Achievements', 234, '61.90'),
(4, 'Exhalation', ' Ted Chiang', 'product_image (3).jpg', 'Fiction', 'Both Are From Different Background And Religion But Yet Their Path Kept Crossing. Is It Fate Or Just Coincidence?', 212, '57.95'),
(5, 'Who Did You Tell?', 'Lesley Kara', 'product_image (4).jpg', 'Fiction', 'Having Reluctantly Moved Back In With Her Mother, In A Quiet Seaside Town Away From The Temptations And Painful Memories Of Her Life Before, Astrid Is Focusing On Her Recovery. She\'s Going To Meetings. Confessing Her Misdeeds. Making Amends To Those She\'s Wronged.', 186, '46.50'),
(6, 'The History Of Philosophy\r\n', 'A C Grayling', 'product_image (5).jpg', 'Fiction', 'The Story Of Philosophy Is An Epic Tale: An Exploration Of The Ideas, Views And Teachings Of Some Of The Most Creative Minds Known To Humanity. But Since The Long-Popular Classic Bertrand Russell\'s History Of Western Philosophy, First Published In 1945, There Has Been No Comprehensive And Entertaining, Single-Volume History Of This Great Intellectual Journey.', 254, '75.50'),
(7, 'Misteri Taming Sari', 'Ibnu Ibrahim', 'product_image (6).jpg', 'Fantasy', 'Kutelusuri Jejak-Jejak Sejarah Mencari Keris Taming Sari, Bermula Dari Kerajaan Majapahit Sehingga Ke Kerajaan Melaka. Kutelusuri Sulatatus Salatin, Sejarah Melayu Dan Tak Lupa Hikayat Hang Tuah Sendiri Kerana Keris Ini Milik Laksamana Hang Tuah.', 158, '29.90'),
(8, 'Aurora', 'Azura Rasiddin', 'product_image (7).jpg', 'Fantasy', 'Aurora. Gadis Berusia Dua Puluh Tahun Yang Mempunyai Impian Dan Fantasi Untuk Menemui Cinta Sejati Seperti Papa Dan Mamanya. Namanya Diberi Sempena Lambang Cinta Papa Dan Mamanya Yang Bertemu Di Bawah Langit Aurora.', 169, '32.00'),
(9, 'Bukan Dark Metalik', 'Pynat Mouri', 'product_image (8).jpg', 'Fantasy', 'Hanya Aku Tahu Perangai Gila Kau...', 143, '28.00'),
(10, 'Cik Delivery', 'Dyadila', 'product_image (9).jpg', 'Fantasy', 'Kisah Cinta Mereka Bukanlah Sehebat Romeo And Juliet. Bukan Seromantis Kisah Cinderella Apatah Lagi Seagung Cinta Rasullullah Dan Saidatina Khadijah. Namun, Kisah Cinta Yang Biasa-Biasa Ini Menjadi Luar Biasa Bila Ada Ikatan Rasa Terhubung Sebelum Cinta.', 151, '28.00'),
(11, 'Maksiat Akhir Zaman', 'Adnin Roslan', 'product_image (10).jpg', 'Fantasy', 'Orang Beriman, Melihat Dosa Ibarat Gunung Yang Menghempap. Manakala Orang Munafik, Melihat Dosa Ibarat Lalat Yang Menghinggap. ', 164, '30.00'),
(12, '23 Sahabat Kesayangan Nabi', 'Ustaz Mohd Hazri', 'product_image (11).jpg', 'Fantasy', 'Buku Ini Menampilkan 23 Personaliti Daripada Kalangan Sahabat Rasulullah SAW Yang Menyayangi Dan Mencintai Nabi Melebihi Cinta Kepada Diri Mereka Sendiri. Mereka Sentiasa Ingin Berdampingan Dengan Nabi Di Dunia Dan Di Syurga. ', 145, '23.00'),
(13, 'Flags Of The World\r\n', 'Joel Wong', 'product_image (12).jpg', 'Facts', 'In This Complete Compendium Of The World’s Flags, Each Nation’s Flag Is Paired With Facts And Tidbits Of History. These Flags Provide A Window Into The Histories, Values, And Cultures Of Countries Around The World.', 259, '69.90'),
(14, 'Good Economics For Hard Times\r\n', 'Abhijit V. Banerjee', 'product_image (13).jpg', 'Facts', 'It Builds On Cutting-Edge Research In Economics - And Years Of Exploring The Most Effective Solutions To Alleviate Extreme Poverty - To Make A Persuasive Case For An Intelligent Interventionism And A Society Built On Compassion And Respect. ', 243, '63.95'),
(15, '12 Lessons To Save Your Life', 'Edith Eger', 'product_image (14).jpg', 'Facts', 'This Practical And Inspirational Guide To Healing From The Bestselling Author Of The Choice Shows Us How To Release Your Self-Limiting Beliefs And Embrace Your Potential.The Prison Is In Your Mind. The Key Is In Your Pocket.', 288, '79.90'),
(16, 'The Gifts Of Imperfection', 'Brene Brown', 'product_image (15).jpg', 'Facts', 'What Transforms This Book From Words To Effective Daily Practices Are The 10 Guideposts To Wholehearted Living. The Guideposts Not Only Help Us Understand The Practices That Will Allow Us To Change Our Lives And Families, They Also Walk Us Through The Unattainable And Sabotaging Expectations That Get In The Way.', 284, '79.90'),
(17, 'Breath: The New Science Of A Lost Art', 'James Nestor', 'product_image (16).jpg', 'Facts', 'There Is Nothing More Essential To Our Health And Well-Being Than Breathing: Take Air In, Let It Out, Repeat 25,000 Times A Day. Yet, As A Species, Humans Have Lost The Ability To Breathe Correctly, With Grave Consequences.', 314, '86.95'),
(18, 'Spinning Top: Kain Songket Mysteries 5', 'Barbara Ismail', 'product_image (17).jpg', 'Facts', 'It Was The Dry Season, When All Kelantan Bursts Into Artistic Bloom, With Theatre And Contests And All Manner Of Entertainment Staged In The Dry Rice Paddies, Which Were Now Cracked And Flat And Hard As Rock. A Large Group Of Men Readied Themselves For A Top Spinning Contest: Those In Charge Of The Tops Rotating Their Shoulders And Loosening Their Already Prominent Biceps.', 214, '39.90'),
(19, 'Secondary Mathematics Tutor\r\n', 'Casco', 'product_image (18).jpg', 'Education', 'The content of this book is contains all topic for secondary mathematic', 254, '42.60'),
(20, 'Tingkatan 4 Koleksi SPM Sejarah Kertas 1\r\n', 'Sasbadi', 'product_image (19).jpg', 'Education', 'This book contains questions and answers for History subject for paper 1 SPM', 121, '8.90'),
(21, 'Tingkatan 4 Praktis Topikal SPM\r\n', 'Ilmu Bakti', 'product_image (20).jpg', 'Education', 'This book published to help students who will sit for SPM examination. This book format is 100% as the real question in SPM.', 134, '7.50'),
(22, 'Contoh Karangan PT3 Bahasa Cina\r\n', 'Penerbitan Pelangi', 'product_image (21).jpg', 'Education', 'This book contains questions and answers for essay example for PT3.', 169, '16.95'),
(23, 'MUET Writing Practice\r\n', 'Global Mediastreet ', 'product_image (22).jpg', 'Education', 'This book is specially written to help students become more familliar with the types of quesions in the real MUET examination.', 134, '7.90'),
(24, 'Primary 4 Conquering Grammar Via Shortcuts', 'CPD', 'product_image (23).jpg', 'Education', 'This book is specially written to help students to mastering their grammar easily.', 287, '32.70');

-- --------------------------------------------------------

--
-- Table structure for table `membersprofile`
--

CREATE TABLE `membersprofile` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `studentid` int(11) DEFAULT NULL,
  `ic` varchar(50) DEFAULT NULL,
  `groupclass` varchar(50) DEFAULT NULL,
  `programname` varchar(50) DEFAULT NULL,
  `programcode` varchar(50) DEFAULT NULL,
  `picture` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `membersprofile`
--

INSERT INTO `membersprofile` (`id`, `name`, `studentid`, `ic`, `groupclass`, `programname`, `programcode`, `picture`, `email`) VALUES
(1, 'Ahmad Faeez Azhari Bin Ismail', 2018672348, '001201-14-0697', 'JCS1105A', 'Diploma in Computer Science', 'CS110', 'faeez.jpg', 'ahmadfaeezazhari@gmail.com'),
(2, 'Muhammad Safwan Aqil Bin Nor Hisham', 2018275146, '000817-14-0287', 'JCS1105A', 'Diploma in Computer Science', 'CS110', 'aqil.jpg', 'safwanmaxz10@gmail.com'),
(3, 'Abdul Rahman Bin Sukarwan', 2018682188, '000507-10-0693', 'JCS1105A', 'Diploma in Computer Science', 'CS110', 'rahman.jpg', 'rahmansukarwan@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(200) NOT NULL,
  `pass` text NOT NULL,
  `fullname` text NOT NULL,
  `role` tinyint(1) NOT NULL COMMENT '1=Admin,2=Staff'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `pass`, `fullname`, `role`) VALUES
('ali', 'aqil', 'ali', 1),
('aqil', 'ahmad', 'ahmad', 1),
('faeez', 'faeez', 'faeez', 1),
('rahman', 'rahman', 'rahman', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `membersprofile`
--
ALTER TABLE `membersprofile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
