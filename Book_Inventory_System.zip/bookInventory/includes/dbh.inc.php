<?php 

$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASSWORD = "";
$DB_DATABASE = "bookstore_db";

$conn = mysqli_connect($DB_HOST,$DB_USER,$DB_PASSWORD,$DB_DATABASE);

?>
