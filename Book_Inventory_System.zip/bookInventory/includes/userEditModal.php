                      <!-- Edit Modal -->
                      <div id="update<?php echo $username ?>" class="modal fade" role="dialog " tabindex="-1" >
                        <form method="POST" class="form-horizontal" role="form">
                          <div class="modal-dialog modal-dialog-centered">
                            <!-- Modal content-->
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Edit User</h4>
                              </div>

                              <div class="modal-body">
                                
                                <input type="hidden" name="userEdit_index" value="<?php echo $username ?>"><!-- user index -->
  

                                <div class="form-group">
                                   <label class="control-label col-sm-2" for="fullname">Name:</label>
                                   <div class="col-sm-8">
                                    <input type="text" name="fullname" id="fullname" class="form-control" value="<?php echo $fullname ?>" required> 
                                  </div>
                                </div>


                                <div class="form-group">
                                  <label class="control-label col-sm-2" for="username">Username:</label>
                                  <div class="col-sm-8">
                                    <input type="text" name="username" id="username" class="form-control" value="<?php echo $username ?>" required  autocomplete="off"> 
                                  </div>
                                </div>


                                <div class="form-group">
                                  <label class="control-label col-sm-2" for="pass">Password:</label>
                                  <div class="col-sm-8">
                                    <input type="password" name="pass" id="pass" class="form-control" value="<?php echo $pass ?>" autocomplete="off">
                                    <small><i>Leave this if you dont want to change the password.</i></small>
                                  </div>
                                </div>


                                <div class="form-group">
                                  <label class="control-label col-sm-2" for="role">User Type:</label>
                                  <div class="col-sm-8">
                                    <select class="form-control" name="role" placeholder="" autocomplete="off" autofocus required>
                                      <option value="1" <?php if($role== "1") echo "selected = selected"; ?> >Admin</option>
                                      <option value="2" <?php if($role== "2") echo "selected = selected"; ?> >Staff</option>
                                    </select>
                                  </div>
                                </div>


                                <div class="modal-footer">
                                  <button type="submit" class="btn btn-primary" name="userEdit_submit"> Edit</button>
                                  <button type="button" class="btn btn-warning" data-dismiss="modal"> Cancel</button>
                                </div>
                              </div>
                          </div>
                        </div>
                      </form>
                      </div>