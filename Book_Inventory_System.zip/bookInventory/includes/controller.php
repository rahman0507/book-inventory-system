<?php

  require 'dbh.inc.php';
  session_start();                                                

  //COOKIES
  if(isset($_POST["remember"])) 
  {
    $username = $_POST['username'];             // assign textbox to variable
    $pass     = $_POST['pass'];
    setcookie ("username",$_POST["username"],time()+ 3600);
    setcookie ("pass",$_POST["pass"],time()+ 3600);   
  } 
  else 
  {
      setcookie("username","");
      setcookie("pass","");
  }

  //LOGIN PART
  if(isset ($_POST['login_submit']))
  {
    $username = $_POST['username'];
    $pass     = $_POST['pass'];
    $query    = "SELECT * FROM users where username='$username' AND pass='$pass'"; 
    $result    = mysqli_query( $conn,$query) or die("Query failed");   // SQL statement for checking
    if(mysqli_num_rows($result) <= 0)              // check either result found or not
      {
        echo "<script> alert('Wrong Username or Password !! Please enter again');window.location='../login.php'</script>";
      }
    else
    {
        $info = mysqli_fetch_array($result);    // returns a row from a recordset
        $_SESSION['fullname'] = $info['fullname'];  // assign field in username to session [user]
        $_SESSION['username'] = $info['username']; //username
        $_SESSION['role']     = $info['role'];
        $_SESSION['pass']     = $info['pass'];

        if($info['role'] == '1')
        {
          header("Location: ../index.php");
          exit();
        }
        elseif($info['role'] == '2')
        {
          header("Location: ../staff/index.php");
          exit();
        }

      }
  }

  //ADD BOOKS
  if(isset ($_POST['add_submit']))
  {
    $add_id       =$_POST['book_id'];
    $add_title    =$_POST['txtTitle']; 
    $add_author   =$_POST['txtAuthor']; 
    $add_category =$_POST['txtCategory']; 
    $add_desc     =$_POST['txtDesc'];
    $add_pages    =$_POST['txtPages'];
    $add_price    =$_POST['txtPrice'];
    $add_picture  =$_POST['txtPicture'];

    if (empty($add_title) && empty($add_author) && empty($add_category) && empty($add_desc) && empty($add_pages) && empty($add_price) && empty($add_price) && empty($add_picture))
    {
      header("Location: ../add.php?submittion=empty");
      exit();
    }
    elseif ( !preg_match("/^[a-zA-Z0-9]*$/",$add_author) )
    {
      header("Location: ../add.php?submittion=char");
      exit();
    }
    elseif ( !is_numeric($add_pages) ) 
    {
      header("Location: ../add.php?submittion=numeric");
      exit();
    }
    elseif ( !is_numeric($add_price) ) 
    {
      header("Location: ../add.php?submittion=numeric");
      exit();
    }
    else
    {
      $query= "INSERT INTO book (book_id,title,author,picture,category,descr,pages,price)values('$add_id','$add_title','$add_author','$add_picture','$add_category','$add_desc','$add_pages','$add_price')" ;
      $result = mysqli_query( $conn,$query);
      header("Location: ../add.php?submittion=success");
      exit();
    }
  }

  //EDIT BOOK PART
  if(isset ($_POST['edit_submit']))
  {
    $edit_title     =$_POST['txtTitle']; 
    $edit_author    =$_POST['txtAuthor'];
    $edit_picture   =$_POST['txtPicture'];
    $edit_category  =$_POST['txtCategory']; 
    $edit_desc      =$_POST['txtDesc']; 
    $edit_pages     =$_POST['txtPages']; 
    $edit_price     =$_POST['txtPrice'];
    $edit_index     =$_POST['edit_index'];
    $category_edit  =$_POST['category_edit'];

    if (empty($edit_picture))
    {
      $query="UPDATE book SET 
            title     ='$edit_title',
            author    ='$edit_author',
            category  ='$edit_category',
            descr     ='$edit_desc',
            pages     ='$edit_pages',
            price     ='$edit_price' 
            WHERE book_id ='$edit_index'";
    }
    else
    {
       $query="UPDATE book SET 
            title     ='$edit_title',
            author    ='$edit_author',
            picture   ='$edit_picture',
            category  ='$edit_category',
            descr     ='$edit_desc',
            pages     ='$edit_pages',
            price     ='$edit_price' 
            WHERE book_id ='$edit_index'";
    }
    
    if ($conn->query($query) == TRUE )
    {
      if ($category_edit  == 'Fiction')
      {
        echo "<script> alert('Edit Successful');window.location='fiction.php'</script>";
      }
      elseif ($category_edit  == 'Fantasy')
      {
        echo "<script> alert('Edit Successful');window.location='fantasy.php'</script>";
      }
      elseif ($category_edit  == 'Facts')
      {
        echo "<script> alert('Edit Successful');window.location='facts.php'</script>";
      }
      elseif ($category_edit  == 'Education')
      {
        echo "<script> alert('Edit Successful');window.location='education.php'</script>";
      }
    } 
    else
    {
      echo "<script> alert('Edit error !! Please try again');window.location='fantasy.php'</script>";
    }
  }


  //DELETE BOOK PART
  if(isset ($_POST['delete_submit']))
  {
    $delete_index = $_POST['delete_index'];
    $query        = "DELETE FROM book WHERE book_id ='$delete_index'";
    $category_del = $_POST['category_del'];
    if ($conn->query($query) === TRUE )
    {
      if ($_POST['category_del'] == 'Fiction')
      {
        echo "<script> alert('Delete Successful');window.location='fiction.php'</script>";
      }
      elseif ($_POST['category_del'] == 'Fantasy')
      {
        echo "<script> alert('Delete Successful');window.location='fantasy.php'</script>";
      }
      elseif ($_POST['category_del'] == 'Facts')
      {
        echo "<script> alert('Delete Successful');window.location='facts.php'</script>";
      }
      elseif ($_POST['category_del'] == 'Education')
      {
        echo "<script> alert('Delete Successful');window.location='education.php'</script>";
      }
    } 
    else{
      echo "<script> alert('Delete error !! Please try again');window.location='fantasy.php'</script>";
    }
  }

  //EDIT USER ONE BY ONE
  if(isset ($_POST['user_submit']))
  {
    $fullname    =$_POST['fullname']; 
    $username    =$_POST['username'];
    $pass        =$_POST['pass'];
    $user_index  =$_POST['user_index'];

    //check duplicate
    $real = mysqli_real_escape_string($conn,$username);
    $check_duplicate = "SELECT username FROM users WHERE username='$real' ";
    $rlt = mysqli_query($conn,$check_duplicate);
    $count = mysqli_num_rows($rlt);
    if ($count > 0)
    {
      echo "<script> alert('Username already taken !! Please try again');window.location='index.php'</script>"; 
    }
    
    $query="UPDATE users SET 
            username    ='$username', 
            fullname    ='$fullname',
            pass        ='$pass'
            WHERE username ='$user_index'  ";

    $result = mysqli_query( $conn,$query) or die (mysqli_error($conn));
    if ($result == TRUE )
    {
      $_SESSION['fullname'] = $_POST['fullname'];
      $_SESSION['username'] = $_POST['username']; 
      $_SESSION['pass'] = $_POST['pass'];  
      echo "<script> alert('Edit Successful');window.location='index.php'</script>";
    } 
    else
    {
       echo "<script> alert('Edit error !! Please try again');window.location='index.php'</script>";
    }
  }

  //ADD USER
  if(isset ($_POST['userAdd_submit']))
  {
    $fullname    =$_POST['fullname']; 
    $username    =$_POST['username'];
    $pass        =$_POST['pass'];
    $role        =$_POST['role'];
    //check duplicate
    $real = mysqli_real_escape_string($conn,$username);
    $check_duplicate = "SELECT username FROM users WHERE username='$real' ";
    $rlt = mysqli_query($conn,$check_duplicate);
    $count = mysqli_num_rows($rlt);
    if ($count > 0)
    {
      echo "<script> alert('Username already taken !! Please try again');window.location='userSetting.php'</script>"; 
    }

    if (empty($fullname) && empty($username) && empty($pass) && empty($role))
    {
      echo "<script> alert('Empty input !! Please try again');window.location='userSetting.php'</script>";
    }
    elseif ( !preg_match("/^[a-zA-Z0-9]*$/",$username) )
    {
      echo "<script> alert('Username error !! Please try again');window.location='userSetting.php'</script>";
    }
    
    else
    {
      $query= "INSERT INTO users (username,fullname,pass,role)values('$username','$fullname','$pass','$role')";
      $result = mysqli_query( $conn,$query);
      echo "<script> alert('Add User Successful');window.location='userSetting.php'</script>";
    }
    
  }




  //EDIT USER SETTING
  if(isset ($_POST['userEdit_submit']))
  {
    $fullname    =$_POST['fullname']; 
    $username    =$_POST['username'];
    $pass        =$_POST['pass'];
    $role        =$_POST['role'];
    $userEdit_index  =$_POST['userEdit_index'];

    //check duplicate
    $real = mysqli_real_escape_string($conn,$username);
    $check_duplicate = "SELECT username FROM users WHERE username='$real' ";
    $rlt = mysqli_query($conn,$check_duplicate);
    $count = mysqli_num_rows($rlt);
    if ($count > 0)
    {
      echo "<script> alert('Username already taken !! Please try again');window.location='userSetting.php'</script>"; 
    }

    
    $query="UPDATE users SET 
            username    ='$username', 
            fullname    ='$fullname',
            pass        ='$pass',
            role        ='$role'
            WHERE username ='$userEdit_index'  ";

    $result = mysqli_query( $conn,$query) or die (mysqli_error($conn));
    if ($result == TRUE )
    {
      echo "<script> alert('Edit Successful');window.location='userSetting.php'</script>";
    } 
    else
    {
       echo "<script> alert('Edit error !! Please try again');window.location='userSetting.php'</script>";
    }
    
  }

  //DELETE USER SETTING
  if(isset ($_POST['userDelete_submit']))
  {
    $userDelete_index = $_POST['userDelete_index'];
    $query            = "DELETE FROM users WHERE username ='$userDelete_index'";

    if ($conn->query($query) === TRUE )
    {
      echo "<script> alert('Delete Successful');window.location='userSetting.php'</script>";
    }
    else{
      echo "<script> alert('Delete error !! Please try again');window.location='userSetting.php'</script>";
    }
  }


  //CALCULATE NUMBER OF BOOKS
  function calcTotalBook($results)
  {
    $count = 0;
    if(mysqli_num_rows($results) > 0 )
    {
      while ($row = mysqli_fetch_array($results)) 
      { 
        $count++;
      }
    }
    return $count;
  }


  function query($query)
  {
    global $conn;

    $result = mysqli_query($conn,$query);
    $rows =[];

    while($row = mysqli_fetch_assoc($result))
    {
        $rows[] = $row;
    }

    return $rows;
  }

?>

