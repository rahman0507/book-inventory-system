                    <!-- Add Modal -->
                      <div id="addUser"  class="modal fade" role="dialog " tabindex="-1" >
                        <form method="POST" class="form-horizontal" role="form">
                          <div class="modal-dialog modal-dialog-centered">
                            <!-- Modal content-->
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Add User</h4>
                              </div>

                              <div class="modal-body">

                                <div class="form-group">
                                   <label class="control-label col-sm-2" for="fullname">Name:</label>
                                   <div class="col-sm-8">
                                    <input type="text" name="fullname" id="fullname" class="form-control" placeholder="Enter your name" autocomplete="off" autofocus required> 
                                  </div>
                                </div>


                                <div class="form-group">
                                  <label class="control-label col-sm-2" for="username">Username:</label>
                                  <div class="col-sm-8">
                                    <input type="text" name="username" id="username" class="form-control" placeholder="Enter your username" autocomplete="off" autofocus required> 
                                  </div>
                                </div>


                                <div class="form-group">
                                  <label class="control-label col-sm-2" for="pass">Password:</label>
                                  <div class="col-sm-8">
                                    <input type="password" name="pass" id="pass" class="form-control" placeholder="Enter your password" autocomplete="off" autofocus required>
                                    
                                  </div>
                                </div>


                                <div class="form-group">
                                  <label class="control-label col-sm-2" for="role">User Type:</label>
                                  <div class="col-sm-8">
                                    <select class="form-control" name="role" placeholder="" autocomplete="off" autofocus required>
                                      <option>---Choose Category---</option>
                                      <option value="1">Admin</option>
                                      <option value="2">Staff</option>
                                    </select>
                                  </div>
                                </div>


                                <div class="modal-footer">
                                  <button type="submit" class="btn btn-primary" name="userAdd_submit"> Save</button>
                                  <button type="button" class="btn btn-warning" data-dismiss="modal"> Cancel</button>
                                </div>
                              </div>
                          </div>
                        </div>
                      </form>
                      </div>
