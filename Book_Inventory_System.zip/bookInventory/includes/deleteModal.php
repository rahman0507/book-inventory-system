                      <!--Delete Modal -->
                      <div id="delete<?php echo $row['book_id']; ?>" class="modal fade" role="dialog">
                         <div class="modal-dialog">
                          <form method="POST">
                            <!-- Modal content-->
                            <div class="modal-content">
                             <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">Delete Book</h4>
                            </div>

                            <div class="modal-body">
                              <input type="hidden" name="delete_index" value="<?php echo $row['book_id']; ?>">
                              <input type="hidden" name="category_del" value="<?php echo $category ?>">
                                <div class="alert alert-danger">Do you really want to delete this book <strong>
                                 <?php echo $row['title']; ?></strong>,by<strong>
                                 <?php echo $row['author']; ?></strong>,with pages <strong>
                                 <?php echo $row['pages']; ?></strong>,at price<strong>
                                 <?php echo $row['price']; ?>
                                </strong> 
                                </div>
                            <div class="modal-footer">
                              <button type="submit" name="delete_submit" class="btn btn-danger" > YES</button>
                              <button type="button" class="btn btn-default" data-dismiss="modal"> NO</button>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>