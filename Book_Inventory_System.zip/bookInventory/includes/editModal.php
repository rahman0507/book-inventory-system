                      <!-- Edit Modal -->
                      <div id="edit<?php echo $row['book_id']; ?>" class="modal fade" role="dialog " tabindex="-1" >
                        <form method="POST" class="form-horizontal" role="form">
                          <div class="modal-dialog modal-lg">
                            <!-- Modal content-->
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Edit Book</h4>
                              </div>

                              <div class="modal-body">
                                
                                <input type="hidden" name="edit_index" value="<?php echo $row['book_id']; ?>"><!-- index book -->
                                <input type="hidden" name="category_edit" value="<?php echo $category ?>">

                                <div class="form-group">
                                  <label class="control-label col-sm-2" for="txtTitle">Title:</label>
                                  <div class="col-sm-8">
                                    <input type="text" class="form-control" id="txtTitle" name="txtTitle" value="<?php echo $row['title']; ?>" required autofocus>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label class="control-label col-sm-2" for="txtAuthor">Author:</label>
                                  <div class="col-sm-8">
                                    <input type="text" class="form-control" id="txtAuthor" name="txtAuthor" value="<?php echo $row['author']; ?>" required>
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label class="control-label col-sm-2" for="cName">Category:</label>
                                  <div class="col-sm-4">
                                    <select class="form-control" name="txtCategory" value="<?php echo $row['category']; ?>" autocomplete="off" autofocus required>
                                      <option value="Fiction" <?php if($row['category'] == "Fiction") echo "selected = selected"; ?> >Fiction</option>
                                      <option value="Fantasy" <?php if($row['category'] == "Fantasy") echo "selected = selected"; ?>>Fantasy</option>
                                      <option value="Facts" <?php if($row['category'] == "Facts") echo "selected = selected"; ?>>Facts</option>
                                      <option value="Education" <?php if($row['category'] == "Education") echo "selected = selected"; ?>>Education</option>
                                    </select>
                                  </div>
                                  
                                  <label class="control-label col-sm-2" for="txtPages">Page:</label>
                                  <div class="col-sm-2">
                                    <input type="text" name="txtPages" class="form-control" autocomplete="off" autofocus required  value="<?php echo $row['pages']; ?>">
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label class="control-label col-sm-2" for="txtPrice">Price:</label>
                                  <div class="col-sm-2">
                                    <input type="price" name="txtPrice" class="form-control" autocomplete="off" autofocus required value="<?php echo $row['price']; ?>">
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label  class="col-sm-2 col-form-label">Description:</label>
                                    <div class="col-sm-10">  
                                      <textarea class="form-control" rows="3" name="txtDesc"> <?php echo $row['descr']; ?></textarea> 
                                    </div>
                                </div>
                                <div class="form-group">
                                  <label class="col-sm-2 col-form-label" for="txtPicture">Book Picture:</label>
                                    <div class="col-sm-2">
                                      <input name="txtPicture" type="file" value="<?php echo $row['price'];?>" autocomplete="off" >
                                    </div>
                                </div>

                                <div class="modal-footer">
                                  <button type="submit" class="btn btn-primary" name="edit_submit"> Edit</button>
                                  <button type="button" class="btn btn-warning" data-dismiss="modal"> Cancel</button>
                                </div>
                              </div>
                          </div>
                        </div>
                      </form>
                      </div>