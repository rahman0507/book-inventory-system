                     <!-- Edit Modal -->
                      <div id="user<?php echo $_SESSION['username'] ?>" class="modal fade" role="dialog " tabindex="-1" >
                        <form method="POST" class="form-horizontal" role="form">
                          <div class="modal-dialog modal-dialog-centered">
                            <!-- Modal content-->
                            <div class="modal-content">

                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Manage Account</h4>
                              </div>

                              <div class="modal-body">
                                <input type="hidden" name="user_index" value="<?php echo $_SESSION['username'] ?>"><!-- user index -->
                                <div class="form-group">
                                   <label class="control-label col-sm-2" for="fullname">Name:</label>
                                   <div class="col-sm-8">
                                    <input type="text" name="fullname" id="fullname" class="form-control" value="<?php echo $_SESSION['fullname'] ?>" required> 
                                  </div>
                                </div>


                                <div class="form-group">
                                  <label class="control-label col-sm-2" for="username">Username:</label>
                                  <div class="col-sm-8">
                                    <input type="text" name="username" id="username" class="form-control" value="<?php echo $_SESSION['username']?>" required  autocomplete="off"> 
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label class="control-label col-sm-2" for="pass">Password:</label>
                                  <div class="col-sm-8">
                                    <input type="password" name="pass" id="pass" class="form-control" value="<?php echo $_SESSION['pass'] ?>" autocomplete="off">
                                    <small><i>Leave this if you dont want to change the password.</i></small>
                                  </div>
                                </div>

                                <div class="modal-footer">
                                  <button type="submit" class="btn btn-primary" name="user_submit"> Save</button>
                                  <button type="button" class="btn btn-warning" data-dismiss="modal"> Cancel</button>
                                </div>

                              </div>
                            </div>
                          </div>
                          </form>
                        </div>

                        




