                      <!--Delete Modal -->
                      <div id="delete<?php echo $username ?>" class="modal fade" role="dialog">
                         <div class="modal-dialog">
                          <form method="POST">
                            <!-- Modal content-->
                            <div class="modal-content">
                             <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">Delete User</h4>
                            </div>

                            <div class="modal-body">
                              <input type="hidden" name="userDelete_index" value="<?php echo $username ?>">
                                <div class="alert alert-danger">Do you really want to delete this user <strong>
                                 <?php echo $fullname; ?>
                                </strong> 
                                </div>
                            <div class="modal-footer">
                              <button type="submit" name="userDelete_submit" class="btn btn-danger" > YES</button>
                              <button type="button" class="btn btn-default" data-dismiss="modal"> NO</button>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>