<?php
  require "includes/controller.php";
  require "includes/header.php";
  require "includes/logoutModal.php";
  if(empty($_SESSION['username']))
  {
    header("location:login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
  <body>
    <div id="wrapper">
      <!-- Sidebar -->
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">Book Inventory System&nbsp&nbsp<i class="fa fa-book"></i></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav side-nav">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active"><a href="add.php"><i class="fa fa-plus-square"></i> Add Book</a></li>
            <li><a href="search.php"><i class="fa fa-search"></i> Search Book</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-list-ul"></i> Book Categories<b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="fiction.php" style="text-decoration: none; color: #FFFFFF;">Fiction</a></li>
                <li><a href="fantasy.php" style="text-decoration: none; color: #FFFFFF;">Fantasy</a></li>
                <li><a href="facts.php" style="text-decoration: none; color: #FFFFFF;">Facts</a></li>
                <li><a href="education.php" style="text-decoration: none; color: #FFFFFF;">Education</a></li>
              </ul>
            </li>
            <li><a href="userSetting.php"><i class="fa fa-users"></i> User Setting</a></li>
            <li><a href="groupmembers.php"><i class="fa fa-file"></i> Members Profile</a></li>
          </ul>  
          <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown user-dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i>&nbsp<?php echo $_SESSION['fullname'] ?> <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="#user<?php echo $_SESSION['username']?>" data-toggle="modal"><i class="fa fa-cog">&nbsp</i> Manage Account</a></li>
                <li class="divider"></li>
                <li><a href="#logout" data-toggle="modal"><i class="fa fa-power-off"></i> Log Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </nav>
      <?php include "includes/userModal.php"; ?>
    <div id="page-wrapper">
    <div class="row">
      <div class="col-lg-12">
      <h1>Add <small>New Book</small></h1>
        <ol class="breadcrumb">
          <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
          <li class="active"><i class="fa fa-plus-square"></i> Add Book</li>
        </ol>

        <!--error message-->
            <?php
              $fullUrl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

              if (strpos($fullUrl, "submittion=empty") == true)
              {
                echo "<div class='alert alert-dismissable alert-danger'>
                      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                      You did not fill in all fields! </a>
                    </div>";
              }
              elseif (strpos($fullUrl, "submittion=char") == true)
              {
                echo "<div class='alert alert-dismissable alert-danger'>
                      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                      You used invalid characters! </a>
                    </div>";
              }
              elseif (strpos($fullUrl, "submittion=numeric") == true)
              {
                echo "<div class='alert alert-dismissable alert-danger'>
                      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                      You used invalid numeric! </a>
                    </div>";
              }
              elseif (strpos($fullUrl, "submittion=email") == true)
              {
                echo "<div class='alert alert-dismissable alert-danger'>
                      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                      You used an invalid e-mail! </a>
                    </div>";
                echo "<p class='error'></p>";
              }
              elseif (strpos($fullUrl, "submittion=success") == true)
              {
                echo "<div class='alert alert-dismissable alert-success'>
                      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                     All the informations are submitted </a>
                    </div>";
              }
            ?>

            <?php
          $id = "0";
          $sql = "SELECT * FROM book";
          $result = $conn->query($sql);
          while($row=$result->fetch_assoc()):
        ?>
        <?php $id= $row['book_id']; ?> <!-- untuk tambah buku to new index -->
        <?php endwhile; ?>

        <form action="includes/controller.php" method="POST">
          <div class="form-group row">
            <label class="col-sm-2 col-form-label">Title</label>
            <div class="col-sm-7">
              <input type="hidden" name="book_id" value="<?php echo $id+1;?>">
              <input type="text" id="title" name="txtTitle" class="form-control" placeholder="" autocomplete="off" autofocus required>
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 col-form-label">Author</label>
            <div class="col-sm-7">
              <input type="text" name="txtAuthor" class="form-control" placeholder="" autocomplete="off" autofocus required>
            </div>
          </div>

          <div class="form-group row">
            <label  class="col-sm-2 col-form-label">Category</label>
            <div class="col-sm-7">
                <select class="form-control" name="txtCategory" placeholder="" autocomplete="off" autofocus required>
                  <option>---Choose Category---</option>
                  <option value="Fiction">Fiction</option>
                  <option value="Fantasy">Fantasy</option>
                  <option value="Facts">Facts</option>
                  <option value="Education">Education</option>
                </select>
            </div>
          </div>

          <div class="form-group row">
            <label  class="col-sm-2 col-form-label">Number of Pages</label>
            <div class="col-sm-2">
              <input type="text" name="txtPages" class="form-control"  placeholder="" autocomplete="off" autofocus required>
            </div>
          </div>

          <div class="form-group row">
            <label  class="col-sm-2 col-form-label">Price</label>
            <div class="col-sm-2">
              <input type="price" name="txtPrice" class="form-control"  placeholder="" autocomplete="off" autofocus required>
            </div>
          </div>

          <div class="form-group row">
            <label  class="col-sm-2 col-form-label">Description</label>
            <div class="col-sm-7">
              <textarea class="form-control" rows="3" name="txtDesc"> </textarea> 
            </div>
          </div>

          <div class="form-group row">
            <label  class="col-sm-2 col-form-label">Book Picture</label>
            <div class="col-sm-7">
              <input name="txtPicture" type="file" autocomplete="off" >
              <input type="hidden" name="id" value="<?php echo $id+1;?>">
            </div>
          </div>

          <center><button class="btn btn-primary" type="submit" class="btn btn-default" name="add_submit">Submit</button>
          <button type="reset" class="btn btn-default">Reset</button></center>
        </form>
        </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->        
    </div><!-- /#wrapper -->
  </body>
</html>