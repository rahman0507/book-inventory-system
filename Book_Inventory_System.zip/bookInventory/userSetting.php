<?php
  require "includes/controller.php";
  require "includes/header.php";
  require "includes/logoutModal.php";
  if(empty($_SESSION['username']))
  {
    header("location:login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
  <body>
    <div id="wrapper">
      <!-- Sidebar -->
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">Book Inventory System&nbsp&nbsp<i class="fa fa-book"></i></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav side-nav">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="add.php"><i class="fa fa-plus-square"></i> Add Book</a></li>
            <li><a href="search.php"><i class="fa fa-search"></i> Search Book</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-list-ul"></i> Book Categories<b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="fiction.php" style="text-decoration: none; color: #FFFFFF;">Fiction</a></li>
                <li><a href="fantasy.php" style="text-decoration: none; color: #FFFFFF;">Fantasy</a></li>
                <li><a href="facts.php" style="text-decoration: none; color: #FFFFFF;">Facts</a></li>
                <li><a href="education.php" style="text-decoration: none; color: #FFFFFF;">Education</a></li>
              </ul>
            </li>
            <li class="active"><a href="userSetting.php"><i class="fa fa-users"></i> User Setting</a></li>
            <li><a href="groupmembers.php"><i class="fa fa-file"></i> Members Profile</a></li>
          </ul>  
          <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown user-dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i>&nbsp<?php echo $_SESSION['fullname'] ?> <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="#user<?php echo $_SESSION['username']?>" data-toggle="modal"><i class="fa fa-cog">&nbsp</i> Manage Account</a></li>
                <li class="divider"></li>
                <li><a href="#logout" data-toggle="modal"><i class="fa fa-power-off"></i> Log Out</a></li>
              </ul>
            </li>
          </ul>

        </div><!-- /.navbar-collapse -->
      </nav>
    <?php include "includes/userModal.php"; ?>

    <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h1>User Setting</h1>
            <ol class="breadcrumb">
              <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li class="active"><i class="fa fa-users"></i> User Setting</li>
            </ol>

        <!-- Search form -->
        <div class="col-sm-12">
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addUser">+ New User</button><br><br>

          <?php include 'includes/addUserModal.php'; ?>
          <div class="white-box">
            <form class="form-horizontal form-material" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
              <div class="form-group">
                <div class="col-md-12">
                <input type="text" id="myInput" placeholder="Search..." class="form-control">
                </div>
              </div>  
        <div class="row">
          <div class="col-lg-12">
            <div class="table-responsive">
              <table class="table table-bordered table-hover table-striped tablesorter">
                <thead>
                  <tr>
                      <th>Bil<i class="fa fa-sort"></i></th>
                      <th>Name <i class="fa fa-sort"></i></th>
                      <th>Username <i class="fa fa-sort"></i></th>
                      <th>Type <i class="fa fa-sort"></i></th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody id="myTable"><?php $x=1;?>
                    <?php 
                    $results = mysqli_query($conn,"SELECT * FROM users");
                    if(mysqli_num_rows($results) > 0 ){
                      while ($row = mysqli_fetch_array($results)) 
                      { 
                        $fullname = $row['fullname'];
                        $username = $row['username'];
                        $role     = $row['role'];
                        $pass     = $row['pass'];
                        $typeName = " ";

                        if($role == "1")
                        {
                          $typeName = "Admin";
                        }
                        elseif ($role == "2")
                        {
                          $typeName = "Staff";
                        }
                        ?>
                    <tr>
                        <td><?php echo $x?></td>
                        <td><?php echo $fullname;?></td>
                        <td><?php echo $username;?></td>
                        <td><?php echo $typeName;?></td>
                        <td><?php $x++?>
                          <a href="#update<?php echo $username ?>" data-toggle="modal">
                              <button type='button' class='btn btn-link'>Update<span aria-hidden='true'></span></button></a> |
                          <a href="#delete<?php echo $username ?>" data-toggle="modal">
                              <button type='button' class='btn btn-link'>Delete<span aria-hidden='true'></span></button></a>

                            <?php include 'includes/userEditModal.php'; ?>
                            <?php include 'includes/userDeleteModal.php'; ?>    
                      </td>
                    </tr>
                  <?php } } ?>      
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->     
    </div><!-- /#wrapper -->
  </body>
  <script src="js/tablesorter/jquery.tablesorter.js"></script>
  <script src="js/tablesorter/tables.js"></script>
  <script>
    var input = document.getElementById("myInput");
    input.addEventListener("keyup", function(event) {
    if (event.keyCode === 13) {
      event.preventDefault();
      document.getElementById("myBtn").click();
    }
    });

    $(document).ready(function(){
    $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
    });
    });

  </script>
</html>