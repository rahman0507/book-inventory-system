<?php
  require "includes/controller.php";
  require "includes/header.php";
  require "includes/logoutModal.php";
  if(empty($_SESSION['username']))
  {
    header("location:login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">

  <body>
    <div id="wrapper">
      <!-- Sidebar -->
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">Book Inventory System&nbsp&nbsp<i class="fa fa-book"></i></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav side-nav">
            <li class="active"><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="add.php"><i class="fa fa-plus-square"></i> Add Book</a></li>
            <li><a href="search.php"><i class="fa fa-search"></i> Search Book</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-list-ul"></i> Book Categories<b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="fiction.php" style="text-decoration: none; color: #FFFFFF;">Fiction</a></li>
                <li><a href="fantasy.php" style="text-decoration: none; color: #FFFFFF;">Fantasy</a></li>
                <li><a href="facts.php" style="text-decoration: none; color: #FFFFFF;">Facts</a></li>
                <li><a href="education.php" style="text-decoration: none; color: #FFFFFF;">Education</a></li>
              </ul>
            </li>
            <li><a href="userSetting.php"><i class="fa fa-users"></i> User Setting</a></li>
            <li><a href="groupmembers.php"><i class="fa fa-file"></i> Members Profile</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown user-dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i>&nbsp<?php echo $_SESSION['fullname'] ?> <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="#user<?php echo $_SESSION['username']?>" data-toggle="modal"><i class="fa fa-cog">&nbsp</i> Manage Account</a></li>
                <li class="divider"></li>
                <li><a href="#logout" data-toggle="modal"><i class="fa fa-power-off"></i> Log Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </nav>
      <?php include "includes/userModal.php"; ?>
      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Dashboard <small>Overview</small></h1>
            <ol class="breadcrumb">
              <li class="active"><i class="fa fa-dashboard"></i> Dashboard</li>
            </ol>
            <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Welcome to Book Inventory System ! </a>
            </div>
          </div>
        </div><!-- /.row -->

        <?php 
          $results      = mysqli_query($conn,"SELECT * FROM book");
          $totalBooks   = calcTotalBook($results); //results only can be used once  //FUNCTION CALL

          $results      = mysqli_query($conn,"SELECT * FROM book WHERE category = 'Fiction'");
          $totalFiction = calcTotalBook($results);

          $results      = mysqli_query($conn,"SELECT * FROM book WHERE category = 'Fantasy'");
          $totalFantasy   = calcTotalBook($results);

          $results      = mysqli_query($conn,"SELECT * FROM book WHERE category = 'Facts'");
          $totalFacts   = calcTotalBook($results);

          $results      = mysqli_query($conn,"SELECT * FROM book WHERE category = 'Education'");
          $totalEducation = calcTotalBook($results);
        ?>
        <div class="row">
          <div class="col-lg-3">
            <div class="panel panel-info">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-xs-6">
                    <i class="fa fa-book fa-5x"></i>
                  </div>
                  <div class="col-xs-6 text-right">
                    <p class="announcement-heading"><?php echo $totalBooks ?></p>
                    <p class="announcement-text">Total Books</p>
                  </div>
                </div>
              </div>
              <a href="search.php">
                <div class="panel-footer announcement-bottom">
                  <div class="row">
                    <div class="col-xs-6">
                      View All Books
                    </div>
                    <div class="col-xs-6 text-right">
                      <i class="fa fa-arrow-circle-right"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>

          <div class="col-lg-3">
            <div class="panel panel-warning">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-xs-6">
                    <i class="fa fa-star fa-5x"></i>
                  </div>
                  <div class="col-xs-6 text-right">
                    <p class="announcement-heading"><?php echo $totalFiction ?></p>
                    <p class="announcement-text">Total Fiction Books</p>
                    <form name="calculator1">
                      <input type="hidden" name="num1" value="<?php echo $totalFiction ?>">
                      <input type="hidden" name="num2" value="<?php echo $totalBooks ?>">
                      <button type="button" class="btn btn-warning btn-xs" onclick="divideFiction()">Average Fiction Books</button>
                    </form>
                  </div>
                </div>
              </div>
              <a href="fiction.php">
                <div class="panel-footer announcement-bottom">
                  <div class="row">
                    <div class="col-xs-6">
                      View All Fiction Books
                    </div>
                    <div class="col-xs-6 text-right">
                      <i class="fa fa-arrow-circle-right"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>

          <div class="col-lg-3">
            <div class="panel panel-danger">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-xs-6">
                    <i class="fa fa-bug fa-5x"></i>
                  </div>
                  <div class="col-xs-6 text-right">
                    <p class="announcement-heading"><?php echo $totalFantasy ?></p>
                    <p class="announcement-text">Total Fantasy Books</p>
                     <form name="calculator2">
                      <input type="hidden" name="num1" value="<?php echo $totalFantasy ?>">
                      <input type="hidden" name="num2" value="<?php echo $totalBooks ?>">
                      <button type="button" class="btn btn-danger btn-xs" onclick="divideFantasy()">Average Fantasy Books</button>
                    </form>
                  </div>
                </div>
              </div>
              <a href="fantasy.php">
                <div class="panel-footer announcement-bottom">
                  <div class="row">
                    <div class="col-xs-6">
                      View All Fantasy Books
                    </div>
                    <div class="col-xs-6 text-right">
                      <i class="fa fa-arrow-circle-right"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>

          <div class="col-lg-3">
            <div class="panel panel-success">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-xs-6">
                    <i class="fa fa-globe fa-5x"></i>
                  </div>
                  <div class="col-xs-6 text-right">
                    <p class="announcement-heading"><?php echo $totalFacts ?></p>
                    <p class="announcement-text">Total Facts Books</p>
                    <form name="calculator3">
                      <input type="hidden" name="num1" value="<?php echo $totalFacts ?>">
                      <input type="hidden" name="num2" value="<?php echo $totalBooks ?>">
                      <button type="button" class="btn btn-success btn-xs" onclick="divideFacts()">Average Facts Books</button>
                    </form>
                  </div>
                </div>
              </div>
              <a href="facts.php">
                <div class="panel-footer announcement-bottom">
                  <div class="row">
                    <div class="col-xs-6">
                      View All Facts Books
                    </div>
                    <div class="col-xs-6 text-right">
                      <i class="fa fa-arrow-circle-right"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>

           <div class="col-lg-3">
            <div class="panel panel-default">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-xs-6">
                    <i class="fa fa-apple fa-5x"></i>
                  </div>
                  <div class="col-xs-6 text-right">
                    <p class="announcement-heading"><?php echo $totalEducation ?></p>
                    <p class="announcement-text">Total Education Books</p>
                    <form name="calculator4">
                      <input type="hidden" name="num1" value="<?php echo $totalEducation ?>">
                      <input type="hidden" name="num2" value="<?php echo $totalBooks ?>">
                      <button type="button" class="btn btn-default btn-xs" onclick="divideEducation()">Average Education Books</button>
                    </form>
                  </div>
                </div>
              </div>
              <a href="education.php">
                <div class="panel-footer announcement-bottom">
                  <div class="row">
                    <div class="col-xs-6">
                      View All Education Books
                    </div>
                    <div class="col-xs-6 text-right">
                      <i class="fa fa-arrow-circle-right"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
        


        <div style="font-size: 35px; "><center>
          <hr width="100%" color="black" >
          <div style="padding-top: 20px;">
            <strong style="padding-bottom: 20px; color: green;">4 Hidden Advantages of Reading a Book</strong> 
          </div>
        </div></center>
        <div><br><center>
          <video src="video/vidBook.mp4" width="852" height="480" autoplay muted loop controls></video></center>
        </div>


      </div><!-- /.row --> 
      </div><!-- /#page-wrapper -->
    </div><!-- /#wrapper -->
  </body>
  <script type="text/javascript">
  function divideFiction()
  {
    var num1 = Number.parseInt(document.calculator1.num1.value);
    var num2 = Number.parseInt(document.calculator1.num2.value);
    var tot = num1/num2;

    alert("Total Average Fiction Books = " + tot);
  }
  function divideFantasy()
  {
    var num1 = Number.parseInt(document.calculator2.num1.value);
    var num2 = Number.parseInt(document.calculator2.num2.value);
    var tot = num1/num2;

    alert("Total Average Fantasy Books = " + tot);
  }function divideFacts()
  {
    var num1 = Number.parseInt(document.calculator3.num1.value);
    var num2 = Number.parseInt(document.calculator3.num2.value);
    var tot = num1/num2;

    alert("Total Average Facts Books = " + tot);
  }function divideEducation()
  {
    var num1 = Number.parseInt(document.calculator4.num1.value);
    var num2 = Number.parseInt(document.calculator3.num2.value);
    var tot = num1/num2;

    alert("Total Average Education Books = " + tot);
  }
</script>
</html>