<?php
  require "includes/controller.php";
  require "includes/header.php";
  require "includes/logoutModal.php";
  if(empty($_SESSION['username']))
  {
    header("location:login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
  <body>
    <div id="wrapper">
      <!-- Sidebar -->
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">Book Inventory System&nbsp&nbsp<i class="fa fa-book"></i></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav side-nav">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="add.php"><i class="fa fa-plus-square"></i> Add Book</a></li>
            <li><a href="search.php"><i class="fa fa-search"></i> Search Book</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-list-ul"></i> Book Categories<b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="fiction.php" style="text-decoration: none; color: #FFFFFF;">Fiction</a></li>
                <li><a href="fantasy.php" style="text-decoration: none; color: #FFFFFF;">Fantasy</a></li>
                <li><a href="facts.php" style="text-decoration: none; color: #FFFFFF;">Facts</a></li>
                <li><a href="education.php" style="text-decoration: none; color: #FFFFFF;">Education</a></li>
              </ul>
            </li>
            <li><a href="userSetting.php"><i class="fa fa-users"></i> User Setting</a></li>
            <li><a href="groupmembers.php"><i class="fa fa-file"></i> Members Profile</a></li>
          </ul>  
        <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown user-dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i>&nbsp<?php echo $_SESSION['fullname'] ?> <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="#user<?php echo $_SESSION['username']?>" data-toggle="modal"><i class="fa fa-cog">&nbsp</i> Users Setting</a></li>
                <li class="divider"></li>
                <li><a href="#logout" data-toggle="modal"><i class="fa fa-power-off"></i> Log Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </nav>
      <?php include "includes/userModal.php"; ?>
      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Category <small>Education</small></h1>
            <ol class="breadcrumb">
              <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li class="active"><i class="fa fa-book"></i> Book Category</li>
            </ol>
      <?php
      $id = "";
      $sql = "SELECT * FROM book WHERE category='Education'";
      $result = $conn->query($sql);
      while($row=$result->fetch_assoc()):
      ?>
      <div id="page-wrapper">
      <?php $category = $row['category']; ?>
        <div class="row" >
          <div class="col-lg-9">
            <div class="table-responsive">
              <table class="table table-bordered table-hover tablesorter">
                <tbody id="myTable">
                  <tr>
                    <td rowspan="5"><img src="uploads/<?php echo $row['picture'] ?>"  alt=""></td>
                    <td class ="container"><b>TITLE: </b><?php echo $row['title']; ?> </td>
                    <td class="text-center" rowspan="5">

                      <a href="#edit<?php echo $row['book_id'];?>" data-toggle="modal">
                      <button type='button' class='btn btn-success'>Edit<span aria-hidden='true'></span></button></a><br><br>
                      <a href="#delete<?php echo $row['book_id'];?>" data-toggle="modal">
                      <button type='button' class='btn btn-danger'>Delete<span aria-hidden='true'></span></button></a>

                      <?php include 'includes/editModal.php'; ?>
                      <?php include 'includes/deleteModal.php'; ?>
                    </td>
                  </tr>
                  <tr>
                    <td><b>AUTHOR: </b><?php echo $row['author']; ?> </td>
                  </tr>
                  <tr>
                    <td><b>DESCRIPTION: </b><?php echo $row['descr']; ?> </td>
                  </tr>
                  <tr>
                    <td><b>PAGE: </b><?php echo $row['pages']; ?> </td>
                  </tr>
                  <tr>
                    <td><b>PRICE: </b>RM<?php echo $row['price']; ?> </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->
    <?php endwhile; ?>
    </div><!-- /#wrapper -->
  </body>
</html>